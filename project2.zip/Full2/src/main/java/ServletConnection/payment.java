package ServletConnection;

import jakarta.servlet.ServletException;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import org.json.JSONObject;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet implementation class payment
 */
public class payment extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public payment() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
            RazorpayClient razorpay = new RazorpayClient("rzp_test_22lnLHr7dNBVF3", "8xG8HSuEavBgQ5fCKtyWT7uq");

            JSONObject orderRequest = new JSONObject();
            orderRequest.put("amount", 50000); // amount in the smallest currency unit
            orderRequest.put("currency", "INR");
            orderRequest.put("receipt", "order_rcptid_11");
            orderRequest.put("payment_capture", 1); // auto capture

            Order order = razorpay.orders.create(orderRequest);
            String orderId = order.get("id");
            
            // Pass the order ID to your JSP
            request.setAttribute("orderId", orderId);
            request.getRequestDispatcher("/payment.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
        }
	}

}
