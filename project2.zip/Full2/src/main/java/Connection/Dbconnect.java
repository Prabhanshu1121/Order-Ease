package Connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Dbconnect {
	public static Connection cont() {
		Connection con=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/projectfull2","root","54112");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return con;
	}

public static void registerrecord(String username,String password,String role) {
	Connection con=cont();
	try {
	String q="insert into loginrecord(username,password,role) values(?,?,?)";
	PreparedStatement ps=con.prepareStatement(q);
	ps.setString(1, username);
	ps.setString(2,password);
	ps.setString(3, role);
	ps.executeUpdate();
	con.close();
	}
	catch(Exception e) {
		e.printStackTrace();
	}
}
public static boolean checklogin(String username,String password,String role) {
	boolean status=false;
	try {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/projectfull2","root","54112");
		PreparedStatement ps=con.prepareStatement("select * from loginrecord where username=? and password=? and role=?");
		ps.setString(1, username);
		ps.setString(2,password);
		ps.setString(3, role);
		ResultSet rs=ps.executeQuery();
		if(rs.next()) {
			status=true;
		}
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	return status;
}
public static int userid(String username, String password, String role) {
    int sno = -1; // Default value indicating login failure
    try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/projectfull2", "root", "54112");
        PreparedStatement ps = con.prepareStatement("SELECT sno FROM loginrecord WHERE username=? AND password=? AND role=?");
        ps.setString(1, username);
        ps.setString(2, password);
        ps.setString(3, role);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            sno = rs.getInt("sno");
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return sno;
}
}
